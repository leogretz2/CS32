#include <iostream>
#include "Voicemail.h"

using namespace std;

int main() {
	Voicemail vm(3);
	vm.say();
	cout << vm.numVMs + 1 << endl;
}