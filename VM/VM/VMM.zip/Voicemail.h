#pragma once
class Voicemail {
	public:
		Voicemail(int num);
		void say();
		int numVMs;

	private:
};